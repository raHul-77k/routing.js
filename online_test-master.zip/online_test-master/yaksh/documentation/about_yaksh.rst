===========
About Yaksh
===========

History
-------

	At FOSSEE, Nishanth had implemented a nice django based app to test for multiple-choice questions. Prabhu Ramachandran was inspired by a programming contest that he saw at PyCon APAC 2011. Chris Boesch, who administered the contest, used a nice web application Singpath that he had built on top of GAE that basically checked your Python code, live. This made it fun and interesting.

	Prabhu wanted an implementation that was not tied to GAE and hence wrote the initial cut of what is now 'Yaksh'. The idea being that anyone can use this to test students programming skills and not have to worry about grading their answers manually and instead do so on their machines.

	The application has since been refactored and maintained by FOSSEE Developers.


Contact
-------

	For further information and support you can contact

	`Python Team at FOSSEE <pythonsupport@fossee.in>`_

License
-------
	This is distributed under the terms of the BSD license.

Authors
-------
	FOSSEE Developers
