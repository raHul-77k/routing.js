==============
Other Features
==============

Grade User
----------

	Grade User is a feature of Yaksh to access students' answer papers for each quiz and grade them where necessary.

	Clicking on the **Grade User** link from the nav bar will show all the courses.

	Click on the **Details** button to show the quizzes associated to a particular course.

	Click on the **Grade User** button next to the quiz name to view all the students who have attempted the quiz.

	Click on the student name to view their submissions.

Monitor
-------

	Monitor is a feature of Yaksh where the moderator can monitor a quiz and view statistics.

	Clicking on the **Monitor** link from the nav bar will show all the courses.

	Click on the **Details** button to show the quizzes associated to a particular course.

	Click on the **Monitor** button next to the quiz name to view all the students who are attempting the quiz.

	Click on the student name to view their submissions.

Grader
------

	Click the **Grader** link on the navigation bar.
	This allows you to regrade answerpapers of students using three ways:

		1. **Question wise regrade**
			Answerpapers can be regraded per Question.
		2. **Quiz wise regrade**
			Answerpapers can be regraded per Quiz.
		3. **User wise regrade**
			Answerpaper can be regraded for a particular student.

