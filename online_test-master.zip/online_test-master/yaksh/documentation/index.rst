Welcome to Yaksh's documentation!
=================================

Yaksh lets user create and take online programming quiz.  Yaksh is an open source project developed by FOSSEE. The code is available on `github <https://github.com/fossee/online_test>`_.
	
The user documentation for the site is organized into a few sections:

.. toctree::

   introduction.rst
   installation.rst
   moderator_dashboard.rst
   about_yaksh.rst