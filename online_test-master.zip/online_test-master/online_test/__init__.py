from __future__ import absolute_import, unicode_literals

from online_test.celery_settings import app as celery_app

__all__ = ('celery_app',)

__version__ = '0.31.1'
