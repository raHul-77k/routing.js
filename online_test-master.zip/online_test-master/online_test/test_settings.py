from online_test.settings import *


MIGRATION_MODULES = {'yaksh': None}